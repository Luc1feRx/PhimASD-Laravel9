<?php
namespace App\Repositories;

interface GenreInterface
{
    //paginate
    public function getGenre();
}
