<?php
namespace App\Repositories;

interface CategoryInterface
{
    //paginate
    public function getCate();
}
