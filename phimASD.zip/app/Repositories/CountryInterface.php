<?php
namespace App\Repositories;

interface CountryInterface
{
    //paginate
    public function getCountries();
}