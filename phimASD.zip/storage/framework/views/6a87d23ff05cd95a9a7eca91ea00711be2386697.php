

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.headers.cards', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container-fluid mt-5">
        <div class="container">

            <div class="container-fluid d-flex align-items-center justify-content-center">
                <div class="col-lg-7 d-flex justify-content-center mb-3">
                    <h3 class="display-4 text-black">Add Categories</h3>
                </div>
            </div>

            <?php echo $__env->make('pages.errors.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('pages.status.status', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <form method="post" action="<?php echo e(route('categories.store')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="form-group">
                            <input type="text" class="form-control" id="exampleFormControlInput1"
                                placeholder="Enter name" name="name">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" id="exampleFormControlInput1"
                                placeholder="Enter slug" name="slug">
                        </div>

                        <div class="form-group d-flex justify-content-center">
                            <button type="submit" class="btn btn-primary">Add New Category</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\PhimASD\resources\views/pages/categories/create.blade.php ENDPATH**/ ?>