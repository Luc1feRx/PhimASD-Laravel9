<div class="header bg-gradient-primary pt-md-7">
    <div class="container-fluid">
        <div class="header-body">
            <!-- Card stats -->
        </div>
    </div>
</div>